package com.example.diana.nuevoproyecto;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.Principal;

public class Inicio extends AppCompatActivity {

    // Declaración de atributos de la clase
    Button iniciarSession;
    Button crearCuenta;
    EditText usuario, pasword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        // Asocia atributos de la clase con elementos gráficos
        iniciarSession= (Button)findViewById(R.id.btEntrar);
        crearCuenta = (Button)findViewById(R.id.btCrearCuenta);
        usuario = (EditText)findViewById(R.id.eTUsuario);
        pasword = (EditText)findViewById(R.id.eTContrasena);
    }

    /**
     * Redirige a la pagina "Crear Cuenta"
     * @param v
     */
    public void crearCuenta (View v){
        Intent intent = new Intent(Inicio.this, CrearCuenta.class);
        startActivity(intent);
    }

    // Verifica que los datos proporcionados por el usuario sean correctos, en caso contrario despliegará un
    // dialog alert
    public void inciarSesion(View view) {
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getReadableDatabase();
        Cursor cursor = sq.rawQuery("select contra from REGISTRO where idUsuario = '" + usuario.getText().toString() + "';",null);
        if(cursor.getCount()>0) {
            cursor.moveToFirst();
            if(cursor.getString(0).equals(pasword.getText().toString())) {
                Intent intent = new Intent(Inicio.this, com.example.diana.nuevoproyecto.Principal.class);
                Bundle bundle = new Bundle();
                bundle.putString("usuario",usuario.getText().toString());
                intent.putExtras(bundle);
                startActivity(intent);
            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(Inicio.this);
                builder.setTitle("Contraseña incorrecta");
                builder.setPositiveButton("Crear cuenta", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Inicio.this, CrearCuenta.class);
                        startActivity(intent);
                    }
                });
                builder.setNegativeButton("Intentar de nuevo", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        } else {
            //Despliega un DialogAlert
            AlertDialog.Builder builder = new AlertDialog.Builder(Inicio.this);
            builder.setTitle("Usuario incorrecto");
            builder.setPositiveButton("Crear cuenta", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(Inicio.this, CrearCuenta.class);
                    startActivity(intent);
                }
            });
            builder.setNegativeButton("Intentar de nuevo", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        cursor.close();
    }

}
