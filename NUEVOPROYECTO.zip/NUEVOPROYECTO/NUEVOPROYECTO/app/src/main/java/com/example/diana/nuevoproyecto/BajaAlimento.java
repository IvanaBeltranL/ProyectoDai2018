package com.example.diana.nuevoproyecto;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BajaAlimento extends AppCompatActivity {
    // Declaración de atributos de la clase
    Bundle bundle;
    EditText nombre;
    Button baja;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baja_alimento);
        // Asocia atributos de la clase con elementos gráficos
        bundle = this.getIntent().getExtras();
        nombre=(EditText)findViewById(R.id.eTNombreAlimento);
        baja =(Button)findViewById(R.id.btAlta);

    }

    /**
     * El método baja elimina un ingrediente de la base de datos a partir del nombre
     * @param view
     */
    public void baja(View view) {
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getWritableDatabase();
        long res =sq.delete("INGREDIENTES","nombreIngrediente = '"+nombre.getText().toString()+"' and idU ='"+bundle.getString("usuario")+"'",null);
        if(res>0) {
            Toast toast = Toast.makeText(this, "Se elimino el alimento", Toast.LENGTH_LONG);
            toast.show();
        }
        else {
            Toast toast = Toast.makeText(this, "No se encontró el alimento", Toast.LENGTH_LONG);
            toast.show();
        }
    }
}
