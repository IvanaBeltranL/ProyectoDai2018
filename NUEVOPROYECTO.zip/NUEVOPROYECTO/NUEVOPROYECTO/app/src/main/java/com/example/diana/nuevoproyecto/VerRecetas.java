package com.example.diana.nuevoproyecto;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class VerRecetas extends AppCompatActivity {

    // Atributos de la clase
    Bundle bundle;
    TextView titulo, procedimiento;
    ListView listV_Ingre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_recetas);
        // Asocia atributos de la clase con elementos gráficos
        bundle = this.getIntent().getExtras();
        titulo = (TextView) findViewById(R.id.tVTituloReceta);
        procedimiento = (TextView) findViewById(R.id.tVProcedimientoConte);
        listV_Ingre= (ListView)findViewById(R.id.listIngreRece);
        String ingredientesDataBase;
        List<String> items = new ArrayList<>();

        // Dspliega la información de la receta a la que se le hizo clic
        // en la pantalla "Recetas App"
        // Obtinen la información de la base de datos
        // Convierte el string de los ingredientes en una lista y la despliega en un listView
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getReadableDatabase();
        Cursor cursor = sq.rawQuery("select nombre, ingredientes, procedimiento  from RECETAS where nombre = '"+bundle.getString("titulo")+"';",null);
        if(cursor.getCount()>0) {
            cursor.moveToFirst();
            titulo.setText(cursor.getString(0));
            ingredientesDataBase = (cursor.getString(1));
            procedimiento.setText(cursor.getString(2));
            items = Arrays.asList(ingredientesDataBase.split("\\s*,\\s*"));
        }
        else{
            Toast toast = Toast.makeText(this,"Hubo un error",Toast.LENGTH_LONG);
            toast.show();
        }
        cursor.close();
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,items);
        listV_Ingre.setAdapter(adapter);
    }


}
