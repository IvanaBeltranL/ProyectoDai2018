package com.example.diana.nuevoproyecto;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class BuscarAlimento extends AppCompatActivity {

    // Declaración de atributos de la clase
    Button buscarAlimento;
    Bundle bundle;
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_alimento);
        // Asocia atributos de la clase a controles gráficos
        buscarAlimento= (Button) findViewById(R.id.btBuscar);
        bundle = this.getIntent().getExtras();
        spinner =(Spinner)findViewById(R.id.spinnerAlimentos);

        //Llena el spinner con los alimentos de la base de datos asociados al usuario
        List<String> alimentos = new ArrayList<String>();
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getReadableDatabase();
        String usuario = bundle.getString("usuario");
        Cursor cursor = sq.rawQuery("select nombreIngrediente from INGREDIENTES where INGREDIENTES.idU ='"+usuario+"';",null);
        //Cursor cursor = sq.rawQuery("select nombreIngrediente from INGREDIENTES ",null);
        while(cursor.moveToNext()){
            alimentos.add(cursor.getString(0));
        }
        cursor.close();
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,alimentos);
        spinner.setAdapter(ad);
    }

    // Este metódo es utilizado cuando se hace click en el boton Buscar en la interfaz buscarAlimento
    public void btBuscar (View v){
        Intent intent = new Intent(BuscarAlimento.this, InformacionAlimento.class);
        String al = spinner.getSelectedItem().toString();
        bundle.putString("alimento",al);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
