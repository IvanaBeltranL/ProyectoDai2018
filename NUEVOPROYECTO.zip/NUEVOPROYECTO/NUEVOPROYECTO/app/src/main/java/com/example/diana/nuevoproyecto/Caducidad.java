package com.example.diana.nuevoproyecto;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Caducidad extends AppCompatActivity {

    ListView listaAlimentos, listaCaducidad;
    Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caducidad);
        // Asocia atributos de la clase con elementos gráficos
        listaAlimentos =(ListView)findViewById(R.id.listAlimento);
        listaCaducidad= (ListView)findViewById(R.id.listCaducidad);
        bundle = this.getIntent().getExtras();
        /**
         * Llena la lista de Alimentos que le pertenecen al usuario
         */
        List<String> alimentos = new ArrayList<String>();
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getReadableDatabase();
        String usuario = bundle.getString("usuario");
        Cursor cursor = sq.rawQuery("select nombreIngrediente from INGREDIENTES where INGREDIENTES.idU ='"+usuario+"';",null);
        while(cursor.moveToNext()){
            alimentos.add(cursor.getString(0));
        }
        cursor.close();
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,alimentos);
        listaAlimentos.setAdapter(adapter);


        //Encuentra la fecha del dia de hoy
        Date hoy = Calendar.getInstance().getTime();
        List<String> caducidad = new ArrayList<String>();
        DatabaseHelper db1 = new DatabaseHelper(this);
        Cursor cursor1 = sq.rawQuery("select caducidad from INGREDIENTES where INGREDIENTES.idU ='"+usuario+"';",null);        //Obtener la fecha del dia
        //Llena la lista con las fechas de caducidad de los alimentos
        while(cursor1.moveToNext()){
            //Recupera las fechas de la caducidad
            String stdiacad = cursor1.getString(0);
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            Date fechaDate = null;
            try {
                fechaDate = formato.parse(stdiacad);
            }
            catch (ParseException ex)
            {
                System.out.println(ex);
            }
            //Hace la resta de las fechas para que nos de los días entre
            // la fecha actual y la fecha de caducidad
            long resta = Math.abs(fechaDate.getTime() - hoy.getTime());

            long endias = resta / (24 * 60 * 60 * 1000);
            //Llenar la lista
            caducidad.add(endias + " días");
        }
        cursor1.close();
        ArrayAdapter adapter1 = new ArrayAdapter(this,android.R.layout.simple_list_item_1,caducidad);
        listaCaducidad.setAdapter(adapter1);

    }
}
