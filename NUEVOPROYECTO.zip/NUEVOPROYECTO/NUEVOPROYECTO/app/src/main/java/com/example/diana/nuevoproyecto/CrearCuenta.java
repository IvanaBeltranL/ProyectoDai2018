package com.example.diana.nuevoproyecto;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CrearCuenta extends AppCompatActivity {

    // Declaración de atributos de la clase
    EditText usuario, pasword;
    Button crear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_cuenta);
        // Asocia atributos de la clase con elementos gráficos
        usuario =(EditText)findViewById(R.id.eTUsuarioCrearCuenta);
        pasword =(EditText)findViewById(R.id.ETContraseñaCrearCuenta);
        crear =(Button)findViewById(R.id.btCrearCuenta);

    }

    // Registra un nuevo usuario en la base de datos
    public void crear(View v){
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase nuevoUsuario = db.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //Toma los valores escritos por el usuario en la interfaz
        contentValues.put("idUsuario", usuario.getText().toString());
        contentValues.put("contra",pasword.getText().toString());
        long res = nuevoUsuario.insert("REGISTRO",null,contentValues);

        // Si el usuario se registro exitosamente se redirige a la página de inicio para que inicie sesión
        // Si no, puede volver a intentarlo con un nuevo usuario
        if (res==-1) {
            Toast toast = Toast.makeText(this, "No se pudo crear la cuenta, pruebe con otro usuario", Toast.LENGTH_LONG);
            toast.show();
        }
        else{
            Intent intent = new Intent(CrearCuenta.this,Inicio.class);
            startActivity(intent);
            Toast toast = Toast.makeText(this,"Se creo la cuenta",Toast.LENGTH_LONG);
            toast.show();
        }
    }

}

