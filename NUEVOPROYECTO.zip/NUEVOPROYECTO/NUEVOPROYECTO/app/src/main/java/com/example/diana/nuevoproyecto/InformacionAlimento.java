package com.example.diana.nuevoproyecto;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class InformacionAlimento extends AppCompatActivity {

    // Declaración de atributos de la clase
    Bundle bundle;
    TextView nombre, cal, cant,cad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacion_alimento);
        // Asocia atributos de la clase con elementos gráficos
        bundle = this.getIntent().getExtras();
        nombre = (TextView) findViewById(R.id.tvNombreInfo);
        cal = (TextView) findViewById(R.id.tvCaloriasInfo);
        cant = (TextView) findViewById(R.id.tvCantidadInfo);
        cad = (TextView) findViewById(R.id.tvCaducidadInfo);
        /**
         * Si el alimento buscado se encuentra en la base de datos
         * se despliegará su informacion en la interfaz
         */
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getReadableDatabase();
        Cursor cursor = sq.rawQuery("select nombreIngrediente, cantidad, calorias, caducidad from INGREDIENTES where nombreIngrediente = '"+bundle.getString("alimento")+"' and idU = '"+bundle.getString("usuario")+"';",null);
        if(cursor.getCount()>0){
            cursor.moveToFirst();
            nombre.setText(cursor.getString(0));
            cant.setText(cursor.getString(1));
            cal.setText(cursor.getString(2));
            cad.setText(cursor.getString(3));
        } else{
            Toast toast = Toast.makeText(this,"No se encuentra ese alimento en la base de datos",Toast.LENGTH_LONG);
            toast.show();
        }
        cursor.close();

    }
}
