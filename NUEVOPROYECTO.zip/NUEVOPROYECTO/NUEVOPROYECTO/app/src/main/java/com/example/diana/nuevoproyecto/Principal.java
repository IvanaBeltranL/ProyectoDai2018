package com.example.diana.nuevoproyecto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Principal extends AppCompatActivity {

    // Declaración de atributos de la clase
    ImageButton baja,alta,receta,info,modificar, alert;
    Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Asocia atributos de la clase con elementos gráficos
        setContentView(R.layout.activity_principal);
        baja =(ImageButton)findViewById(R.id.imBtBaja);
        alta =(ImageButton)findViewById(R.id.imBtAlta);
        info =(ImageButton)findViewById(R.id.imBtBuscarIngredientes);
        receta =(ImageButton)findViewById(R.id.imBtBuscarReceta);
        modificar = (ImageButton)findViewById(R.id.imBtModificar);
        alert = (ImageButton)findViewById(R.id.imbtAle);
        bundle = this.getIntent().getExtras();
    }

    // Cada botón reenvía al usuario a una pantalla diferente
    // Ya sea "InformacionAlimento","Alta Alimento","BajaAlimento","Modificar" o "Caducidad"
    public void imbtInfoAlimento(View view) {
        Intent intent = new Intent(Principal.this,BuscarAlimento.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void imbtBaja(View view) {
        Intent intent = new Intent(Principal.this,BajaAlimento.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void imbtRecetas(View view) {
        Intent intent = new Intent(Principal.this,Recetas.class);
        startActivity(intent);
    }


    public void imbtAlta(View view) {
        Intent intent = new Intent(Principal.this,AltaAlimento.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void imbtModificar(View view) {
        Intent intent = new Intent(Principal.this,Modificar.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void imbtAlert (View view) {
        Intent intent = new Intent(Principal.this,Caducidad.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
