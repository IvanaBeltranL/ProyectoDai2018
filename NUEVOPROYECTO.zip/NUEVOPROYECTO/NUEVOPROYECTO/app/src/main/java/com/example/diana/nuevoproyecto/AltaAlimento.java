package com.example.diana.nuevoproyecto;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AltaAlimento extends AppCompatActivity {

    // Declaración de atributos de la clase
    Bundle bundle;
    EditText nom,cal,cant,cad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alta_alimento);
        // Asocia atributos de la clase con elementos gráficos
        bundle = this.getIntent().getExtras();
        nom = (EditText)findViewById(R.id.eTNombreAlimento);
        cal = (EditText)findViewById(R.id.eTCalorias);
        cant = (EditText)findViewById(R.id.eTCantidad);
        cad = (EditText)findViewById(R.id.eTCaducidad);
    }
    //
    public void altaU(View view) {
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getReadableDatabase();
        /**
         * Para obtener la id del nuevo alimento buscamos en la base de datos
         * cual es la id del último alimento agregado y le sumamos uno para tener id consecutivas
         */
        Cursor cursor = sq.rawQuery("select idIngrediente from INGREDIENTES",null);
        int id = cursor.getCount()+1;
        cursor.close();
        SQLiteDatabase nuevoAlimento = db.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        /**Toma los valores escritos por el usuario en la interfaz
         *  y los usa para insertarlos en la base de datos
         */

        contentValues.put("idIngrediente", id);
        contentValues.put("nombreIngrediente",nom.getText().toString());
        contentValues.put("calorias",cal.getText().toString());
        contentValues.put("cantidad",cant.getText().toString());
        contentValues.put("caducidad",cad.getText().toString());
        contentValues.put("idU",bundle.getString("usuario"));
        long res = nuevoAlimento.insert("INGREDIENTES",null,contentValues);
        //Si se puede añadir o no el alimento se desplegará el mensaje correspondiente
        if (res == -1) {
            Toast toast = Toast.makeText(this, "No se pudo añadir el alimento", Toast.LENGTH_LONG);
            toast.show();
        }
        else {

            Toast toast = Toast.makeText(this, "Se añadió el alimento", Toast.LENGTH_LONG);
            toast.show();
        }
    }
}
