package com.example.diana.nuevoproyecto;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context context) {
        super(context, "ListFood", null, 1);
    }

    @Override
    // Creamos las tablas de nuestra base de datos y le insertamos valores a las tablas
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table REGISTRO( idUsuario text primary key, contra text);");
        sqLiteDatabase.execSQL("create table INGREDIENTES( idIngrediente text primary key, nombreIngrediente text, calorias integer, cantidad integer, caducidad date , idU text references REGISTRO(idUsuario) );");
        sqLiteDatabase.execSQL("create table RECETAS( idReceta text primary key, nombre text, ingredientes text, procedimiento text);");

        //Se insertan valores a la tabla REGISTRO donde estan almacenados los usuarios y sus contraseñas
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Diana','cookiesandcream');");
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Ivana','coco');");
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Andrea','fresa');");
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Daniela','vainilladelabuena');");
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Ximena','chocolate');");
        //Se insertan valores a la tabla INGREDIENTES
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('1','Manzana',72,5,'19/05/2018','Diana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('2','Platano',105,3,'21/05/2018','Diana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('3','Yogurth',143,1,'20/05/2018','Diana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('4','Espinaca',74,8,'26/05/2018','Diana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('5','Galletas',120,10,'25/05/2018','Diana');");

        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('6','Helado',130,1,'19/06/2018','Ivana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('7','Cereal',362,3,'19/07/2018','Ivana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('8','Barritas',170,6,'21/06/2018','Ivana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('9','Leche',58,5,'26/05/2018','Ivana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('10','Huevo',80,10,'19/05/2018','Ivana');");

        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('11','Pasta',380,5,'20/05/2018','Andrea');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('12','Atun',100,7,'19/11/2018','Andrea');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('13','Papas',274,3,'22/05/2018','Andrea');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('14','Pollo',220,2,'31/05/2018','Andrea');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('15','Aguacate',160,1,'19/05/2018','Andrea');");

        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('16','Manzana',72,5,'19/05/2018','Daniela');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('17','Platano',105,3,'21/05/2018','Daniela');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('18','Yogurth',143,1,'20/05/2018','Daniela');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('19','Espinaca',74,8,'26/05/2018','Daniela');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('20','Galletas',120,10,'25/05/2018','Daniela');");

        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('21','Helado',130,1,'19/06/2018','Ximena');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('22','Cereal',362,3,'19/07/2018','Ximena');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('23','Barritas',170,6,'21/06/2018','Ximena');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('24','Leche',58,5,'26/05/2018','Ximena');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('25','Huevo',80,10,'19/05/2018','Ximena');");
        //Se insertan valores a la tabla RECETAS
        sqLiteDatabase.execSQL("insert into RECETAS values('A','Aguacate con Atún','Atun, Aguacate, Pepino,Aceite de oliva, Salsa de soya, Sal y Pimienta', '1. Cortar el atún, aguacate, y pepinos en cubitos y ponerlos en un recipiente. 2.Hacer la salsa. Mezclar aceite de olvia y salsa de soya en otro recipiente, poner sal y pimienta al gusto 3.Añadir la salsa al atún y verduras y mezclarlos bien.');");
        sqLiteDatabase.execSQL("insert into RECETAS values('B','Tostadas de frijoles y nopales','Tostadas de maíz, frijoles molidos, nopales, aceite y queso', 'Calienta el aceite en un sarte, agrega los nopales y sal y cúbrelo con una tapa. Espera 5 min hasta que los nopales queden secos, apaga el fuego. Ponle nopales a tu tostada y agrega el queso');");
        sqLiteDatabase.execSQL("insert into RECETAS values('C','Licuado de Manza y Avena','Manzana, leche, almendras picadas, avena y endulzante al gusto', 'P1. Mezclar todo en la licuadora, y servir');");
        sqLiteDatabase.execSQL("insert into RECETAS values('D','Calabazas asadas','calabazas, cacahuates, queso, vinagre, aceite, sal y pimienta', 'Corta las calabacitas en tiras finas, cocinalas sobre una parrilla caliente hasta que queden asadas. Luego ponlas en un bowl y agrega el cacahuate, queso, vinagre, aceite, sal y pimienta');");
        sqLiteDatabase.execSQL("insert into RECETAS values('E','Sandwich de pavo','Rebanas de pan, jamon de pavo, queso, jitomate, lechuga y mayonesa', 'Calienta el pan, y ponle mayonesa. Encima acomoda las rebanadas de lechuga, jitomate , jamon y queso');");
        sqLiteDatabase.execSQL("insert into RECETAS values('F','Helado de Fresas','yogurt, fresas, endulzante', 'Pon todos los ingredientes en el procesador de alimentos y muele hasta tener una consistencia suave de helado');");
        sqLiteDatabase.execSQL("insert into RECETAS values('G','Salteado de pimiento y brocoli ','Pimientos, Salsa de tomate, ajo,brocolí, vinagre, aceite, pimienta y sal', 'Se realiza un salteado de verduras y se agregan las demás hierbas aromáticas para un plano con gran sabor y aroma');");
        sqLiteDatabase.execSQL("insert into RECETAS values('H','Revuleto de acelgas','Caldo de verduas, acelgas, huevos, queso, crema,perejil, ajo, cebolla, aceite, sal', 'Sofrie la cebolla hasta que sea de color transparente, añade el ajo y luego la acelga, el caldo, el perejil y revuelve. Añade la sal, pimienta y queso al gusto. Sirve y coloca un huevo por encima');");


    }

    // Este método elimina las tablas que ya se encuantren en la base de datos y les vuelve a insertar los valores predeterminados
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("drop table if exists REGISTRO");
        sqLiteDatabase.execSQL("drop table if exists INGREDIENTES");
        sqLiteDatabase.execSQL("drop table if exists RECETAS");

        sqLiteDatabase.execSQL("create table REGISTRO( idUsuario text primary key, contra text);");
        sqLiteDatabase.execSQL("create table INGREDIENTES( idIngrediente text primary key, nombreIngredientes text, calorias double, cantidad double, caducidad date , idU text references REGISTRO(idUsuario) );");
        sqLiteDatabase.execSQL("create table RECETAS( idReceta text primary key, nombre text, ingredientes text, procedimiento text);");

        //Insertar tablas
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Diana','cookiesandcream');");
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Ivana','coco');");
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Andrea','fresa');");
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Daniela','vainilladelabuena');");
        sqLiteDatabase.execSQL("insert into REGISTRO values ('Ximena','chocolate');");

        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('1','Manzana',72,5,'19/05/2018','Diana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('2','Platano',105,3,'21/05/2018','Diana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('3','Yogurth',143,1,'20/05/2018','Diana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('4','Espinaca',74,8,'26/05/2018','Diana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('5','Galletas',120,10,'25/05/2018','Diana');");

        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('6','Helado',130,1,'19/06/2018','Ivana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('7','Cereal',362,3,'19/07/2018','Ivana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('8','Barritas',170,6,'21/06/2018','Ivana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('9','Leche',58,5,'26/05/2018','Ivana');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('10','Huevo',80,10,'19/05/2018','Ivana');");

        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('11','Pasta',380,5,'20/05/2018','Andrea');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('12','Atún',100,7,'19/11/2018','Andrea');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('13','Papas',274,3,'22/05/2018','Andrea');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('14','Pollo',220,2,'31/05/2018','Andrea');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('15','Aguacate',160,1,'19/05/2018','Andrea');");

        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('16','Manzana',72,5,'19/05/2018','Daniela');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('17','Platano',105,3,'21/05/2018','Daniela');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('18','Yogurth',143,1,'20/05/2018','Daniela');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('19','Espinaca',74,8,'26/05/2018','Daniela');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('20','Galletas',120,10,'25/05/2018','Daniela');");

        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('21','Helado',130,1,'19/06/2018','Ximena');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('22','Cereal',362,3,'19/07/2018','Ximena');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('23','Barritas',170,6,'21/06/2018','Ximena');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('24','Leche',58,5,'26/05/2018','Ximena');");
        sqLiteDatabase.execSQL("insert into INGREDIENTES values ('25','Huevo',80,10,'19/05/2018','Ximena');");

        sqLiteDatabase.execSQL("insert into RECETAS values('A','Aguacate con Atún','Atun, Aguacate, Pepino, Aceite de oliva, Salsa de soya, Sal, Pimienta', '1. Cortar el atún, aguacate, y pepinos en cubitos y ponerlos en un recipiente. 2.Hacer la salsa. Mezclar aceite de olvia y salsa de soya en otro recipiente, poner sal y pimienta al gusto 3.Añadir la salsa al atún y verduras y mezclarlos bien.');");
        sqLiteDatabase.execSQL("insert into RECETAS values('B','Tostadas de frijoles y nopales','Tostadas de maíz, frijoles molidos, nopales, aceite y queso', 'Calienta el aceite en un sarte, agrega los nopales y sal y cúbrelo con una tapa. Espera 5 min hasta que los nopales queden secos, apaga el fuego. Ponle nopales a tu tostada y agrega el queso');");
        sqLiteDatabase.execSQL("insert into RECETAS values('C','Licuado de Manza y Avena','Manzana, leche, almendras picadas, avena, endulzante al gusto', 'P1. Mezclar todo en la licuadora, y servir');");
        sqLiteDatabase.execSQL("insert into RECETAS values('D','Calabazas asadas','calabazas, cacahuates, queso, vinagre, aceite, sal y pimienta', 'Corta las calabacitas en tiras finas, cocinalas sobre una parrilla caliente hasta que queden asadas. Luego ponlas en un bowl y agrega el cacahuate, queso, vinagre, aceite, sal y pimienta');");
        sqLiteDatabase.execSQL("insert into RECETAS values('E','Sandwich de pavo','Rebanas de pan, jamon de pavo, queso, jitomate, lechuga y mayonesa, Calienta el pan, y ponle mayonesa. Encima acomoda las rebanadas de lechuga, jitomate , jamon y queso');");
        sqLiteDatabase.execSQL("insert into RECETAS values('F','Helado de Fresas','yogurt, fresas, endulzante', 'Pon todos los ingredientes en el procesador de alimentos y muele hasta tener una consistencia suave de helado');");
        sqLiteDatabase.execSQL("insert into RECETAS values('G','Salteado de pimiento y brocoli ','Pimientos, Salsa de tomate, ajo,brocolí, vinagre, aceite, pimienta y sal', 'Se realiza un salteado de verduras y se agregan las demás hierbas aromáticas para un plano con gran sabor y aroma');");
        sqLiteDatabase.execSQL("insert into RECETAS values('H','Revuleto de acelgas','Caldo de verduas, acelgas, huevos, queso, crema,perejil, ajo, cebolla, aceite, sal', 'Sofrie la cebolla hasta que sea de color transparente, añade el ajo y luego la acelga, el caldo, el perejil y revuelve. Añade la sal, pimienta y queso al gusto. Sirve y coloca un huevo por encima');");
    }
}
