package com.example.diana.nuevoproyecto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Recetas extends AppCompatActivity {

    ImageButton web;
    ImageButton app;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Asocia atributos de la clase con elementos gráficos
        setContentView(R.layout.activity_recetas);
        web= (ImageButton) findViewById(R.id.imBtPaginaWeb);
        // Cada botón reenvía a una pantalla distinta
        app = (ImageButton) findViewById(R.id.imBtListadoRecetas);
        web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Recetas.this, RecetasWeb.class);
                startActivity(intent);
            }
        });
        app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Recetas.this, RecetasApp.class);
                startActivity(intent);
            }
        });
    }
}
