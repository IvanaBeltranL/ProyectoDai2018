package com.example.diana.nuevoproyecto;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class Modificar extends AppCompatActivity {

    // Declaración de atributos de la clase
    Spinner spinner;
    EditText cant;
    Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);
        // Asocia atributos de la clase con elementos gráficos
        cant =(EditText)findViewById(R.id.eTNuevaCantidad);
        spinner=(Spinner)findViewById(R.id.spinnerAlimentos);
        bundle = this.getIntent().getExtras();

        //Llena el spinner con los alimentos del usuario
        List<String> alimentos = new ArrayList<String>();
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getReadableDatabase();
        String usuario = bundle.getString("usuario");
        Cursor cursor = sq.rawQuery("select nombreIngrediente from INGREDIENTES where INGREDIENTES.idU ='"+usuario+"';",null);
        //Cursor cursor = sq.rawQuery("select nombreIngrediente from INGREDIENTES ;",null);
        while(cursor.moveToNext()){
            alimentos.add(cursor.getString(0));
        }
        cursor.close();
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,alimentos);
        spinner.setAdapter(ad);
        db.close();
        sq.close();
    }
    // Actualiza la cantidad del alimento en la base de datos
    public void modificar(View view) {
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getWritableDatabase();
        sq.execSQL("update INGREDIENTES set cantidad = "+cant.getText().toString()+ " where nombreIngrediente like '"+spinner.getSelectedItem().toString()+"' and idU like '"+bundle.getString("usuario")+"'");

    }
}
