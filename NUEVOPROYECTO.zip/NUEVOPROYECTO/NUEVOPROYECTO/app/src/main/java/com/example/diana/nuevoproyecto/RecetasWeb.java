package com.example.diana.nuevoproyecto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class RecetasWeb extends AppCompatActivity {
    WebView w;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recetas_web);
        // Asocia atributos de la clase con elementos gráficos
        w =(WebView)findViewById(R.id.webView);
        // Carga la pagina web seleccionada
        w.loadUrl("https://www.kiwilimon.com/recetas");
        w.getSettings().setJavaScriptEnabled(true);
        w.setWebViewClient(new WebViewClient());
    }


}
