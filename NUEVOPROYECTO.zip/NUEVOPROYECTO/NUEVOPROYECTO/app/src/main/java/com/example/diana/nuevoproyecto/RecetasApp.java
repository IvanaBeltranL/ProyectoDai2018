package com.example.diana.nuevoproyecto;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class RecetasApp extends AppCompatActivity {

    ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recetas_app);
        // Asocia atributos de la clase con elementos gráficos
        lista =(ListView)findViewById(R.id.listaRecetas);

        List<String> recetas = new ArrayList<String>();
        DatabaseHelper db = new DatabaseHelper(this);
        SQLiteDatabase sq = db.getReadableDatabase();
        Cursor cursor = sq.rawQuery("select RECETAS.nombre from RECETAS",null);
        while(cursor.moveToNext()){
            recetas.add(cursor.getString(0));
        }
        cursor.close();

        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,recetas);
        lista.setAdapter(adapter);

        // Despliega en un listView las recetas almacenadas en la base de datos
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String titulo = parent.getItemAtPosition(position).toString();
                Intent intent = new Intent(RecetasApp.this, VerRecetas.class);
                Bundle bundle= new Bundle();
                bundle.putString("titulo",titulo.toString());
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

    }




}
